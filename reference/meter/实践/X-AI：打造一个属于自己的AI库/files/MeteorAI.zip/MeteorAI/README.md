# MeteorAI
> pip install meteor：开发一个属于你自己的包

# 第一部分：自己手撸 Activation Functions
- Sigmoid
- Tanh
- ReLU
- LeakyReLU
- ELU
- GELU（高斯误差线性单元，用近似公式）
- Swish
- Softplus

# 第二部分：自己手撸 Loss Functions

- Mean Squared Error (MSE)
- Mean Absolute Error (MAE)
- Huber Loss
- Cross Entropy Loss
- Binary Cross Entropy (BCE)
- Hinge Loss（SVM常用）
- Smooth L1 Loss
- KL Divergence Loss

# 第三部分：自己手撸 Optimizer Functions

- SGD	
- SGD + Momentum
- AdaGrad	
- RMSProp	
- Adam

# 第四部分：自己手撸 Scheduler Functions

- StepLR
- ExponentialLR
- CosineAnnealingLR

# 第五部分：自己手撸 Normalization Functions

- Batch Normalization (BN)
- Layer Normalization (LN)
- Instance Normalization (IN)
- Group Normalization (GN)
- Layer Scale Normalization (LSN)

