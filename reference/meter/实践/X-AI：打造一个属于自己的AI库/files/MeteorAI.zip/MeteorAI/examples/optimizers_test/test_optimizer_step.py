# tests/test_optimizer_step.py
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from path_config import BASE_PATH
sys.path.append(BASE_PATH)
import torch
import matplotlib.pyplot as plt
from meteorai.optimizers.optimizer import SGD, SGDMomentum, AdaGrad, RMSProp, Adam

def test_optimizer(optimizer_class, name):
    x = torch.tensor([0.0], requires_grad=True)
    optimizer = optimizer_class([x], lr=0.1)

    x_history = []

    for step in range(100):
        optimizer.zero_grad()
        loss = (x - 3) ** 2
        loss.backward()
        optimizer.step()

        x_history.append(x.item())

    plt.plot(x_history, label=name)
    print(f"{name} final x: {x.item():.4f}")

def main():
    optimizers = [
        (SGD, 'SGD'),
        (SGDMomentum, 'SGD+Momentum'),
        (AdaGrad, 'AdaGrad'),
        (RMSProp, 'RMSProp'),
        (Adam, 'Adam'),
    ]

    plt.figure(figsize=(8, 6))
    for optim_class, name in optimizers:
        test_optimizer(optim_class, name)

    plt.xlabel('Step')
    plt.ylabel('x value')
    plt.title('Optimizer Convergence')
    plt.legend()
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    main()
