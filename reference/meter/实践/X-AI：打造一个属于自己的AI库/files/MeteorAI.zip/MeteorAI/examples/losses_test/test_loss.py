import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import torch

# 动态引入路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from path_config import BASE_PATH
sys.path.append(BASE_PATH)

from meteorai.losses.loss import MSELoss, MAELoss, BCELoss, CrossEntropyLossBinary


def test_loss(loss_class, loss_name, y_true, y_pred_range, is_classification=False):
    loss_fn = loss_class()

    preds = np.linspace(*y_pred_range, 100)
    losses = []

    for pred in preds:
        # 将预测值和真实值转换成 torch.Tensor
        pred_tensor = torch.tensor([pred], dtype=torch.float32)
        true_tensor = torch.tensor([y_true], dtype=torch.float32)
        # 计算Loss
        l = loss_fn(pred_tensor, true_tensor)
        losses.append(l.item())  # 使用 .item() 获取Python原生数值

    # plot
    plt.plot(preds, losses, label=loss_name)

    # 打印关键样本loss
    print(f"==== {loss_name} ====")
    for sp in [y_pred_range[0], (y_pred_range[0] + y_pred_range[1]) / 2, y_pred_range[1]]:
        # 打印指定样本的loss数值
        pred_tensor = torch.tensor([sp], dtype=torch.float32)
        true_tensor = torch.tensor([y_true], dtype=torch.float32)
        l = loss_fn(pred_tensor, true_tensor)
        print(f"Pred={sp:.2f} -> Loss={l.item():.4f}")


def test_cross_entropy():
    preds = np.linspace(0, 1, 100)
    losses = []

    for p in preds:
        # 两类的预测值，pred_tensor 应该是形状 (batch_size, 2)，即一个样本有两个logits
        pred_tensor = torch.tensor([[1 - p, p]], dtype=torch.float32)  # 两类概率的logits
        target_tensor = torch.tensor([1], dtype=torch.int64)           # 真值是类别1
        l = CrossEntropyLossBinary()(pred_tensor, target_tensor)
        losses.append(l.item())  # 使用 .item() 获取Python原生数值

    plt.plot(preds, losses, label="CrossEntropyLossBinary")

    print("==== CrossEntropyLossBinary ====")
    for sp in [0.0, 0.5, 1.0]:
        pred_tensor = torch.tensor([[1 - sp, sp]], dtype=torch.float32)
        target_tensor = torch.tensor([1], dtype=torch.int64)
        l = CrossEntropyLossBinary()(pred_tensor, target_tensor)
        print(f"Pred(1 class prob)={sp:.2f} -> Loss={l.item():.4f}")


def main():
    plt.figure(figsize=(10, 6))

    # 回归Loss
    test_loss(MSELoss, "MSELoss", y_true=1.0, y_pred_range=(-1, 2))
    test_loss(MAELoss, "MAELoss", y_true=1.0, y_pred_range=(-1, 2))

    # 二分类Loss
    test_loss(BCELoss, "BCELoss", y_true=1.0, y_pred_range=(0, 1))

    # 二分类 CrossEntropy
    test_cross_entropy()

    plt.xlabel("Prediction")
    plt.ylabel("Loss")
    plt.title("Loss Functions Visualization")
    plt.legend()
    plt.grid(True)
    plt.show()


if __name__ == "__main__":
    main()
