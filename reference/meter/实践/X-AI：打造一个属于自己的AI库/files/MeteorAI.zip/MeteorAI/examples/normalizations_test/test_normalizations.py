# 测试
import torch
from meteorai.normalizations.normalization import (
    BatchNorm1d, LayerNorm, InstanceNorm, GroupNorm, LayerScaleNorm
)

import torch


def test_normalization_layers():
    # 设置随机种子
    torch.manual_seed(0)

    # 输入张量，尺寸为 (batch_size, num_features, height, width)
    x = torch.randn(8, 32, 32, 32)  # (batch_size=8, num_features=16, height=32, width=32)

    # BatchNorm1d 测试
    batch_norm = BatchNorm1d(num_features=32)
    out_batch_norm = batch_norm(x.view(8, 32, -1).transpose(1, 2))  # BatchNorm1d 期望的输入形状 (N, L, C)
    print(f'BatchNorm1d output shape: {out_batch_norm.shape}')

    # LayerNorm 测试
    layer_norm = LayerNorm(normalized_shape=32)
    out_layer_norm = layer_norm(x)
    print(f'LayerNorm output shape: {out_layer_norm.shape}')

    # InstanceNorm 测试
    instance_norm = InstanceNorm(num_features=32)
    out_instance_norm = instance_norm(x)
    print(f'InstanceNorm output shape: {out_instance_norm.shape}')

    # GroupNorm 测试
    group_norm = GroupNorm(num_groups=4, num_channels=32)
    out_group_norm = group_norm(x)
    print(f'GroupNorm output shape: {out_group_norm.shape}')

    # LayerScaleNorm 测试
    layer_scale_norm = LayerScaleNorm(normalized_shape=32)
    out_layer_scale_norm = layer_scale_norm(x)
    print(f'LayerScaleNorm output shape: {out_layer_scale_norm.shape}')


if __name__ == "__main__":
    test_normalization_layers()

