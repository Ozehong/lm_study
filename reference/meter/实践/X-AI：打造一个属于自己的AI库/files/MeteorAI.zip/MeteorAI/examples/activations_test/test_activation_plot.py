# tests/test_activation_plot.py
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from path_config import BASE_PATH
sys.path.append(BASE_PATH)
import torch
import matplotlib.pyplot as plt
from meteorai.activations.activation import Sigmoid, Tanh, ReLU, LeakyReLU, ELU, GELU, Swish, Softplus

def plot_activation(activation, name):
    x = torch.linspace(-5, 5, 500)
    y = activation(x)

    plt.figure(figsize=(6, 4))
    plt.plot(x.numpy(), y.numpy())
    plt.title(name)
    plt.grid(True)
    plt.xlabel('Input')
    plt.ylabel('Output')
    plt.show()

def main():
    activations = {
        'Sigmoid': Sigmoid(),
        'Tanh': Tanh(),
        'ReLU': ReLU(),
        'LeakyReLU': LeakyReLU(),
        'ELU': ELU(),
        'GELU': GELU(),
        'Swish': Swish(),
        'Softplus': Softplus(),
    }

    for name, act in activations.items():
        plot_activation(act, name)

if __name__ == "__main__":
    main()
