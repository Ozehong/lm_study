import sys
import os
import torch
import matplotlib.pyplot as plt
from meteorai.losses.loss import (
    MSELoss, MAELoss, HuberLoss, BCELoss, CrossEntropyLossBinary,
    HingeLoss, SmoothL1Loss, KLDivergenceLoss
)

def plot_loss_curve(loss_fn, name, task='regression'):
    if task == 'regression':
        preds = torch.linspace(-3, 3, 500)
        target = torch.zeros_like(preds)  # 目标为0
    elif task == 'classification':
        preds = torch.linspace(-10, 10, 500)
        target = torch.ones_like(preds).long()  # 标签为1，并确保是长整型
    else:
        raise ValueError("Unknown task")

    losses = []
    for p in preds:
        # For classification, reshape target to match the expected shape
        target_tensor = target[0].unsqueeze(0)  # Ensure target is a 1D tensor for each prediction
        if task == 'classification':
            # For classification, the prediction should have shape (batch_size, num_classes)
            pred_tensor = torch.tensor([[p, 0]], dtype=torch.float32)  # Create a 2-class logit prediction
        else:
            pred_tensor = torch.tensor([p], dtype=torch.float32)  # For regression, just use the prediction value

        losses.append(loss_fn(pred_tensor, target_tensor).item())

    plt.figure(figsize=(6, 4))
    plt.plot(preds.numpy(), losses)
    plt.title(name)
    plt.grid(True)
    plt.xlabel('Prediction')
    plt.ylabel('Loss')
    plt.show()

def main():
    loss_functions = {
        'MSELoss': (MSELoss(), 'regression'),
        'MAELoss': (MAELoss(), 'regression'),
        'HuberLoss': (HuberLoss(), 'regression'),
        'BCELoss': (BCELoss(), 'classification'),
        'CrossEntropyLossBinary': (CrossEntropyLossBinary(), 'classification'),
        'HingeLoss': (HingeLoss(), 'classification'),
        'SmoothL1Loss': (SmoothL1Loss(), 'regression'),
        'KLDivergenceLoss': (KLDivergenceLoss(), 'classification'),
    }

    for name, (loss_fn, task) in loss_functions.items():
        print(f"Testing {name}")
        plot_loss_curve(loss_fn, name, task)

if __name__ == "__main__":
    main()
