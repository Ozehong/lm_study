# tests/test_scheduler.py
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from path_config import BASE_PATH
sys.path.append(BASE_PATH)
import torch
import matplotlib.pyplot as plt
from meteorai.optimizers.optimizer import SGD  # 用之前写好的简易SGD
from meteorai.schedulers.scheduler import StepLR, ExponentialLR, CosineAnnealingLR

def plot_scheduler(scheduler_class, scheduler_kwargs, title):
    # 一个假参数，用来测试
    x = torch.nn.Parameter(torch.zeros(1))
    optimizer = SGD([x], lr=0.1)
    scheduler = scheduler_class(optimizer, **scheduler_kwargs)

    lrs = []
    for step in range(100):
        scheduler.step()
        lrs.append(optimizer.param_groups[0]['lr'])

    plt.plot(lrs, label=title)

def main():
    plt.figure(figsize=(8,6))
    plot_scheduler(StepLR, {"step_size":10, "gamma":0.5}, "StepLR")
    plot_scheduler(ExponentialLR, {"gamma":0.9}, "ExponentialLR")
    plot_scheduler(CosineAnnealingLR, {"T_max":100}, "CosineAnnealingLR")

    plt.xlabel("Steps")
    plt.ylabel("Learning Rate")
    plt.title("Learning Rate Schedulers")
    plt.legend()
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    main()
