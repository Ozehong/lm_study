# meteorai/losses/loss.py

import torch


class MSELoss:
    def __call__(self, prediction, target):
        return torch.mean((prediction - target) ** 2)


class MAELoss:
    def __call__(self, prediction, target):
        return torch.mean(torch.abs(prediction - target))


class HuberLoss:
    def __init__(self, delta=1.0):
        self.delta = delta

    def __call__(self, prediction, target):
        error = prediction - target
        abs_error = torch.abs(error)
        quadratic = torch.minimum(abs_error, torch.tensor(self.delta))
        linear = abs_error - quadratic
        return torch.mean(0.5 * quadratic ** 2 + self.delta * linear)


class BCELoss:
    def __call__(self, prediction, target, eps=1e-7):
        prediction = torch.clamp(prediction, eps, 1 - eps)
        return torch.mean(-(target * torch.log(prediction) + (1 - target) * torch.log(1 - prediction)))


class CrossEntropyLossBinary:
    def __call__(self, prediction, target, eps=1e-7):
        # prediction: logits (not sigmoid), 预测张量是 (batch_size, 2)
        prediction = torch.clamp(prediction, -100, 100)  # 防止过大
        bce = torch.nn.functional.cross_entropy(prediction, target)  # 使用 CrossEntropy 损失
        return bce


class HingeLoss:
    def __call__(self, prediction, target):
        # target should be {-1, 1}
        return torch.mean(torch.clamp(1 - prediction * target, min=0))


class SmoothL1Loss:
    def __call__(self, prediction, target):
        diff = torch.abs(prediction - target)
        return torch.mean(torch.where(diff < 1, 0.5 * diff ** 2, diff - 0.5))


class KLDivergenceLoss:
    def __call__(self, prediction, target, eps=1e-7):
        prediction = torch.clamp(prediction, eps, 1)
        target = torch.clamp(target, eps, 1)
        return torch.mean(target * torch.log(target / prediction))
