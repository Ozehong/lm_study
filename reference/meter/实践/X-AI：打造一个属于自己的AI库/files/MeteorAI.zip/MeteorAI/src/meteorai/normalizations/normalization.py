import torch

class BatchNorm1d(torch.nn.Module):
    def __init__(self, num_features, eps=1e-5, momentum=0.1):
        super(BatchNorm1d, self).__init__()
        self.num_features = num_features
        self.eps = eps
        self.momentum = momentum

        # 可学习的参数
        self.gamma = torch.nn.Parameter(torch.ones(num_features))
        self.beta = torch.nn.Parameter(torch.zeros(num_features))

        # 均值和方差的移动平均
        self.running_mean = torch.zeros(num_features)
        self.running_var = torch.ones(num_features)

    def forward(self, x):
        # 计算均值和方差
        mean = x.mean(dim=0)  # 对 batch 维度求均值
        var = x.var(dim=0, unbiased=False)  # 对 batch 维度求方差

        # 使用移动平均
        self.running_mean = self.running_mean * (1 - self.momentum) + mean * self.momentum
        self.running_var = self.running_var * (1 - self.momentum) + var * self.momentum

        # 归一化
        x_hat = (x - mean) / torch.sqrt(var + self.eps)

        # 恢复尺度和偏移
        out = self.gamma * x_hat + self.beta
        return out



class LayerNorm(torch.nn.Module):
    def __init__(self, normalized_shape, eps=1e-5):
        super(LayerNorm, self).__init__()
        self.normalized_shape = normalized_shape
        self.eps = eps

        # 可学习的参数
        self.gamma = torch.nn.Parameter(torch.ones(normalized_shape))
        self.beta = torch.nn.Parameter(torch.zeros(normalized_shape))

    def forward(self, x):
        # 计算均值和方差
        mean = x.mean(dim=-1, keepdim=True)
        var = x.var(dim=-1, keepdim=True, unbiased=False)

        # 归一化
        x_hat = (x - mean) / torch.sqrt(var + self.eps)

        # 恢复尺度和偏移
        out = self.gamma * x_hat + self.beta
        return out


class InstanceNorm(torch.nn.Module):
    def __init__(self, num_features, eps=1e-5):
        super(InstanceNorm, self).__init__()
        self.num_features = num_features
        self.eps = eps

        # 可学习的参数
        self.gamma = torch.nn.Parameter(torch.ones(num_features))
        self.beta = torch.nn.Parameter(torch.zeros(num_features))

    def forward(self, x):
        # 计算均值和方差
        mean = x.mean(dim=[2, 3], keepdim=True)
        var = x.var(dim=[2, 3], keepdim=True, unbiased=False)

        # 归一化
        x_hat = (x - mean) / torch.sqrt(var + self.eps)

        # 恢复尺度和偏移
        out = self.gamma.view(1, self.num_features, 1, 1) * x_hat + self.beta.view(1, self.num_features, 1, 1)
        return out


class GroupNorm(torch.nn.Module):
    def __init__(self, num_groups, num_channels, eps=1e-5):
        super(GroupNorm, self).__init__()
        self.num_groups = num_groups
        self.num_channels = num_channels
        self.eps = eps

        # 可学习的参数
        self.gamma = torch.nn.Parameter(torch.ones(num_channels))
        self.beta = torch.nn.Parameter(torch.zeros(num_channels))

    def forward(self, x):
        # 计算均值和方差
        N, C, H, W = x.shape
        x = x.view(N, self.num_groups, C // self.num_groups, H, W)

        mean = x.mean(dim=[2, 3, 4], keepdim=True)
        var = x.var(dim=[2, 3, 4], keepdim=True, unbiased=False)

        # 归一化
        x_hat = (x - mean) / torch.sqrt(var + self.eps)

        # 恢复尺度和偏移
        x_hat = x_hat.view(N, C, H, W)
        out = self.gamma.view(1, C, 1, 1) * x_hat + self.beta.view(1, C, 1, 1)
        return out


class LayerScaleNorm(torch.nn.Module):
    def __init__(self, normalized_shape, eps=1e-5):
        super(LayerScaleNorm, self).__init__()
        self.normalized_shape = normalized_shape
        self.eps = eps

        # 可学习的参数
        self.gamma = torch.nn.Parameter(torch.ones(normalized_shape))

    def forward(self, x):
        # 计算均值和方差
        mean = x.mean(dim=-1, keepdim=True)
        var = x.var(dim=-1, keepdim=True, unbiased=False)

        # 归一化
        x_hat = (x - mean) / torch.sqrt(var + self.eps)

        # 恢复尺度
        out = self.gamma * x_hat
        return out
