# meteorai/optim/scheduler.py

import math

class StepLR:
    def __init__(self, optimizer, step_size, gamma=0.1):
        self.optimizer = optimizer
        self.step_size = step_size
        self.gamma = gamma
        self.last_epoch = 0

    def step(self):
        self.last_epoch += 1
        if self.last_epoch % self.step_size == 0:
            for param_group in self.optimizer.param_groups:
                param_group['lr'] *= self.gamma

class ExponentialLR:
    def __init__(self, optimizer, gamma):
        self.optimizer = optimizer
        self.gamma = gamma

    def step(self):
        for param_group in self.optimizer.param_groups:
            param_group['lr'] *= self.gamma

class CosineAnnealingLR:
    def __init__(self, optimizer, T_max, eta_min=0.):
        self.optimizer = optimizer
        self.T_max = T_max
        self.eta_min = eta_min
        self.last_epoch = 0
        self.base_lrs = [group['lr'] for group in optimizer.param_groups]

    def step(self):
        self.last_epoch += 1
        for i, param_group in enumerate(self.optimizer.param_groups):
            lr = self.eta_min + (self.base_lrs[i] - self.eta_min) * \
                 (1 + math.cos(math.pi * self.last_epoch / self.T_max)) / 2
            param_group['lr'] = lr
