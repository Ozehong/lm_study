# meteorai/layers/activation.py

import math
import torch


class Sigmoid:
    def __call__(self, x):
        return 1 / (1 + torch.exp(-x))


class Tanh:
    def __call__(self, x):
        return torch.tanh(x)


class ReLU:
    def __call__(self, x):
        return torch.clamp(x, min=0)


class LeakyReLU:
    def __init__(self, negative_slope=0.01):
        self.negative_slope = negative_slope

    def __call__(self, x):
        return torch.where(x > 0, x, self.negative_slope * x)


class ELU:
    def __init__(self, alpha=1.0):
        self.alpha = alpha

    def __call__(self, x):
        return torch.where(x > 0, x, self.alpha * (torch.exp(x) - 1))


class GELU:
    # 使用近似公式：0.5 * x * (1 + tanh(sqrt(2/pi)*(x + 0.044715*x^3)))
    def __call__(self, x):
        return 0.5 * x * (1 + torch.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x ** 3)))


class Swish:
    def __call__(self, x):
        return x * torch.sigmoid(x)


class Softplus:
    def __call__(self, x):
        return torch.log(1 + torch.exp(x))
