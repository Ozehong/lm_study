import torch
import torch.nn as nn


class TransformerLayer(nn.Module):
    def __init__(self, d_model, nhead, d_ff):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.ReLU(),
            nn.Linear(d_ff, d_model)
        )
        self.norm1 = nn.LayerNorm(d_model)  # Post-LN
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, x):
        # 自注意力子层（Post-LN结构）
        attn_output, _ = self.self_attn(x, x, x)
        x = self.norm1(x + attn_output)  # 残差连接 + LayerNorm

        # 前馈子层
        ffn_output = self.ffn(x)
        x = self.norm2(x + ffn_output)  # 残差连接 + LayerNorm
        return x


# 使用示例
d_model = 512
nhead = 8
d_ff = 2048
layer = TransformerLayer(d_model, nhead, d_ff)
x = torch.randn(10, 32, d_model)  # (seq_len, batch_size, d_model)
output = layer(x)  # 输出形状不变
print(output)