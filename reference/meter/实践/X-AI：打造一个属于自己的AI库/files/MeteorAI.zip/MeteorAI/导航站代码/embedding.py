import torch
import torch.nn as nn
import numpy as np


# 定义一个简单的嵌入层
class SimpleEmbedding(nn.Module):
    def __init__(self, vocab_size, embed_dim):
        super(SimpleEmbedding, self).__init__()
        # 使用nn.Embedding来初始化嵌入层
        # vocab_size是词汇表大小，embed_dim是嵌入空间的维度
        self.embedding = nn.Embedding(vocab_size, embed_dim)

    def forward(self, x):
        # 输入x是一个包含词索引的Tensor，返回对应的嵌入向量
        return self.embedding(x)


# 模拟的词汇表大小和嵌入维度
vocab_size = 10  # 假设我们有10个词汇
embed_dim = 5  # 我们希望将每个词映射到5维的嵌入空间

# 创建模型实例
model = SimpleEmbedding(vocab_size, embed_dim)

# 生成一些模拟的词索引输入，假设每个样本是一个词的索引
input_indices = torch.tensor([1, 3, 5, 7, 9])  # 假设我们的输入是这5个词

# 计算对应的嵌入表示
output_embeddings = model(input_indices)

# 输出结果
print("输入的词索引：", input_indices)
print("对应的嵌入向量：")
print(output_embeddings)
