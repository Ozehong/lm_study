import torch


class CustomFFN:
    def __init__(self, input_dim, hidden_dim, output_dim, activation="gelu"):
        """
        手动实现 FFN，不使用 PyTorch 高级 API，仅依赖 torch 进行底层计算。
        """
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim

        # 初始化权重（遵循标准正态分布 * 0.02，符合 Transformer 初始化）
        self.W1 = torch.randn(input_dim, hidden_dim) * 0.02
        self.b1 = torch.zeros(hidden_dim)
        self.W2 = torch.randn(hidden_dim, output_dim) * 0.02
        self.b2 = torch.zeros(output_dim)

        # 选择激活函数
        if activation == "relu":
            self.activation = self.relu
        elif activation == "gelu":
            self.activation = self.gelu
        else:
            raise ValueError("Unsupported activation function")

    def relu(self, x):
        """ 手动实现 ReLU 函数 """
        return torch.max(x, torch.tensor(0.0))

    def gelu(self, x):
        """ 手动实现 GELU（Gaussian Error Linear Unit）近似计算 """
        return 0.5 * x * (1 + torch.tanh(torch.sqrt(torch.tensor(2.0 / 3.1415926535)) * (x + 0.044715 * x ** 3)))

    def forward(self, X):
        """ 手动执行 FFN 前向传播 """
        # 第一层：线性变换 + 激活函数
        H = torch.matmul(X, self.W1) + self.b1  # XW1 + b1
        H = self.activation(H)  # 非线性激活

        # 第二层：线性变换
        Y = torch.matmul(H, self.W2) + self.b2  # HW2 + b2
        return Y


# 测试 FFN
ffn = CustomFFN(input_dim=512, hidden_dim=2048, output_dim=512)
sample_input = torch.randn(1, 512)  # 模拟输入
output = ffn.forward(sample_input)
print(output.shape)  # 输出应为 (1, 512)
