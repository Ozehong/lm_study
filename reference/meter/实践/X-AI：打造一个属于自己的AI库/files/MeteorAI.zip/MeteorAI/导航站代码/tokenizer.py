import re
from collections import Counter


# 1. 加载数据：分割文本成单词，并将其转化为字符对的格式
def get_vocab(texts):
    vocab = Counter()
    for text in texts:
        words = text.split()
        for word in words:
            # 在每个词的尾部添加空格符，确保词间的空格不会被分开
            word = ' '.join(list(word)) + ' </w>'
            vocab[word] += 1
    return vocab


# 2. 计算词汇表中每对字符的频率
def get_stats(vocab):
    pairs = Counter()
    for word, freq in vocab.items():
        symbols = word.split()
        for i in range(len(symbols) - 1):
            pair = (symbols[i], symbols[i + 1])
            pairs[pair] += freq
    return pairs


# 3. 合并频率最高的字符对
def merge_vocab(pair, vocab):
    replacement = ''.join(pair)
    new_vocab = {}
    bigram = ' '.join(pair)
    replacement_with_space = replacement + ' </w>'
    for word in vocab:
        new_word = word.replace(bigram, replacement_with_space)
        new_vocab[new_word] = vocab[word]
    return new_vocab


# 4. 执行 BPE 合并步骤
def bpe(texts, num_merges):
    vocab = get_vocab(texts)
    print("Initial vocabulary:")
    print(vocab)

    for i in range(num_merges):
        pairs = get_stats(vocab)
        if not pairs:
            break
        # 获取出现次数最多的字符对
        most_frequent_pair = max(pairs, key=pairs.get)
        print(f"Merge {i + 1}: {most_frequent_pair}")
        vocab = merge_vocab(most_frequent_pair, vocab)

    return vocab


# 5. 使用 BPE 分词
def encode_with_bpe(texts, num_merges=10):
    final_vocab = bpe(texts, num_merges)
    print("\nFinal vocabulary after BPE:")
    print(final_vocab)

    # 获取最终词汇表中的所有子词
    subwords = set()
    for word in final_vocab.keys():
        subwords.update(word.split())

    return subwords


# 示例文本数据
texts = [
    "low lower lowest",
    "new newer newest",
    "buy buys buyer buying",
]

# 运行 BPE 分词
subwords = encode_with_bpe(texts, num_merges=10)

print("\nSubwords in the final vocabulary:")
print(subwords)
