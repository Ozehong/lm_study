import torch
import torch.nn as nn
import torch.nn.functional as F

class SelfAttention(nn.Module):
    def __init__(self, embed_dim):
        super(SelfAttention, self).__init__()
        # 定义 Query, Key, Value 的权重矩阵
        self.query = nn.Linear(embed_dim, embed_dim)
        self.key = nn.Linear(embed_dim, embed_dim)
        self.value = nn.Linear(embed_dim, embed_dim)
        self.embed_dim = embed_dim

    def forward(self, x):
        # 计算 Query, Key, Value 向量
        Q = self.query(x)
        K = self.key(x)
        V = self.value(x)

        # 计算 Attention 权重
        attention_scores = torch.matmul(Q, K.transpose(-2, -1)) / self.embed_dim**0.5  # 缩放点积
        attention_weights = F.softmax(attention_scores, dim=-1)  # 使用 Softmax 归一化

        # 使用 Attention 权重对 Value 进行加权求和
        output = torch.matmul(attention_weights, V)
        return output, attention_weights

# 测试 Self-Attention
batch_size = 2
seq_len = 4
embed_dim = 8

x = torch.rand(batch_size, seq_len, embed_dim)  # 随机生成一个输入张量
self_attention = SelfAttention(embed_dim)
output, attention_weights = self_attention(x)

print("Output shape:", output.shape)  # 应该是 (batch_size, seq_len, embed_dim)
print("Attention Weights shape:", attention_weights.shape)  # 应该是 (batch_size, seq_len, seq_len)
