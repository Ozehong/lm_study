import torch
import torch.optim as optim
import math

# 假设你有一个简单的模型
class SimpleNN(torch.nn.Module):
    def __init__(self):
        super(SimpleNN, self).__init__()
        self.fc1 = torch.nn.Linear(784, 256)
        self.fc2 = torch.nn.Linear(256, 10)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

# 创建模型实例
model = SimpleNN()

# 定义优化器
initial_lr = 0.01
optimizer = optim.SGD(model.parameters(), lr=initial_lr)

# 假设的训练数据
dummy_input = torch.randn(32, 784)  # 假设32个样本，每个样本784维
dummy_target = torch.randint(0, 10, (32,))  # 假设32个样本的目标标签（0-9）

# 定义损失函数
criterion = torch.nn.CrossEntropyLoss()

# 学习率调整策略
max_epochs = 100
step_size = 10  # 阶梯衰减，每10个epoch衰减一次
lr_decay = 0.5  # 阶梯衰减的衰减率
decay_steps = 10  # 指数衰减，每10个epoch衰减一次
cosine_decay = True  # 是否使用余弦衰减

# 训练循环
for epoch in range(max_epochs):
    model.train()

    # 前向传播
    optimizer.zero_grad()
    output = model(dummy_input)
    loss = criterion(output, dummy_target)

    # 反向传播和优化
    loss.backward()
    optimizer.step()

    # 每个epoch输出损失
    print(f"Epoch {epoch + 1}: Loss = {loss.item()}")

    # 学习率调整：阶梯衰减
    if (epoch + 1) % step_size == 0:
        for param_group in optimizer.param_groups:
            param_group['lr'] *= lr_decay
        print(f"  Step Decay: Learning Rate = {optimizer.param_groups[0]['lr']}")

    # 学习率调整：指数衰减
    if (epoch + 1) % decay_steps == 0:
        for param_group in optimizer.param_groups:
            param_group['lr'] *= lr_decay
        print(f"  Exponential Decay: Learning Rate = {optimizer.param_groups[0]['lr']}")

    # 学习率调整：余弦衰减
    if cosine_decay:
        lr = 0.5 * initial_lr * (1 + math.cos(math.pi * epoch / max_epochs))
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
        print(f"  Cosine Decay: Learning Rate = {lr}")
