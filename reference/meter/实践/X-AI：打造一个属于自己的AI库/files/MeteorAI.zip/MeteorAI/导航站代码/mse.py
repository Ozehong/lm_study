import torch

class MSELossCustom(torch.nn.Module):
    def __init__(self):
        super(MSELossCustom, self).__init__()

    def forward(self, prediction, target):
        # 计算预测值与真实值的差
        loss = torch.mean((prediction - target) ** 2)
        return loss

# 测试代码
pred = torch.tensor([0.5, 0.8, 0.1], requires_grad=True)
target = torch.tensor([1.0, 0.5, 0.0])

loss_fn = MSELossCustom()
loss = loss_fn(pred, target)
print("MSE Loss:", loss.item())

# 反向传播
loss.backward()
print("Pred's gradient:", pred.grad)
