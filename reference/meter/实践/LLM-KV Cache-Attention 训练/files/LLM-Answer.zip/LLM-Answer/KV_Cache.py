import numpy as np
import torch
import time
import math
import torch.nn.functional as F
torch.set_printoptions(8)
kv_cache = [
    {"k": None, "v": None}  # 每层一个字典
    for _ in range(12)
]
def gelu(x):
    """
        Task: Use the torch API to implement the approximate calculation formula of the `GELU`
        activation function. The formula is as follows (you need to paste it into the latex
        online conversion website)
        Website: https://www.latexlive.com/
        Formula: \frac{1}{2} x\left[1+\tanh \left(\sqrt{\frac{2}{\pi}}\left(x+0.044715 x^{3}\right)\right)\right]
        
        Input: Tensor
        Output: Tensor
    """
    # 为什么要使用gelu而不使用其他激活函数？
    return 0.5 * x * (1 + torch.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * x**3)))

def softmax(x):
    """
        Task: Use torch API to implement `softmax` function, search the specific formula by yourself
        Input: Tensor
        Output: Tensor
        Formula: \text{Softmax}(x_i) = \frac{e^{x_i}}{\sum_{j=1}^{n} e^{x_j}}
    """
    x = x - x.max(dim=-1, keepdim=True).values  # 避免数值爆炸
    return torch.exp(x) / torch.sum(torch.exp(x), dim=-1, keepdim=True)


def layer_norm(x, g_b, eps:float = 1e-5):
    """
        Task: Use torch API to implement `layernorm` function, search `layernorm` by yourself
        Input: 
            x: Tensor
            g_b: dictionary that load from gpt2 weight. g-gamma and b-bias are the keys
        Output: Tensor
        Formula: \mu &= \frac{1}{H} \sum_{i=1}^{H} x_i \\
                \sigma &= \sqrt{\frac{1}{H} \sum_{i=1}^{H} (x_i - \mu)^2 + \epsilon} \\
                \text{LayerNorm}(x_i) &= \gamma_i \cdot \frac{x_i - \mu}{\sigma} + \beta_i
    """
    g, b = torch.Tensor(g_b['g']), torch.Tensor(g_b['b'])
    # 考虑一下为什么Transformer用layer_norm而不用batch_norm？
    # 为什么要keepdim保持维度，因为我们通常要把这个均值 / 标准差 广播（broadcast） 回原始张量上做减法除法。如果不保留维度，广播就会出错或不自然。
    # 均值
    mean = x.mean(dim=-1, keepdim=True)
    # 标准差
    std = x.std(dim=-1, keepdim=True)

    # 归一化   eps作用：避免除零错误
    # 广播是 NumPy 和 PyTorch 中非常重要的一个概念，允许不同形状的张量在进行算术运算时自动对齐，避免手动扩展数组，保持代码简洁。
    normalized = (x - mean) / (std + eps)

    # 缩放和偏移
    output = g * normalized + b
    return output

def linear(x, w_b):  # [m, in], [in, out], [out] -> [m, out]
    """
        Task: implement linear layer 
        Input: 
            x: Tensor
            w_b: dictionary that load from gpt2 weight. w-weight and b-bias are the keys
        Output: Tensor
    """
    w, b = w_b['w'], w_b['b']
    if isinstance(w, np.ndarray):
        w = torch.from_numpy(w).to(x.dtype).to(x.device)
    if isinstance(b, np.ndarray):
        b = torch.from_numpy(b).to(x.dtype).to(x.device)
    return torch.matmul(x, w) + b

def ffn(x, mlp):  # [n_seq, n_embd] -> [n_seq, n_embd]
    """
        Task: use `gelu` `linear` to implement ffn
        Notes: x --linear--> --gelu--> --linear--> output
        Input: 
            x: Tensor
            mlp: dictionary that load from gpt2 weight. w_b1 and w_b2 are the params of two linear layer
        Output: Tensor
    """
    w_b1, w_b2 = mlp['c_fc'], mlp['c_proj']
    x = linear(x, w_b1)
    x = gelu(x)
    x = linear(x, w_b2)
    return x


def attention(q, k, v, mask, layer_idx):  # [n_q, d_k], [n_k, d_k], [n_k, d_v], [n_q, n_k] -> [n_q, d_v]
    """
        Task: use torch API to implement attention computation according to formula(1) of the following paper
              where d_k account for the last dimension of `k`
        Paper: https://arxiv.org/abs/1706.03762
        Input: 
            q: Tensor
            k: Tensor
            v: Tensor
            mask: Tensor
            mlp: dictionary that load from gpt2 weight. w_b1 and w_b2 are the params of two linear layer
        Output: Tensor
    """

    d_k = q.size(-1)
    scores = torch.matmul(q, k.T) / torch.sqrt(torch.tensor(d_k, dtype=torch.float32))
    if mask is not None:
        scores = scores + mask
    attention = F.softmax(scores, dim=-1)
    output = torch.matmul(attention, v)
    return output



def mha(x, attn, layer_idx, n_head):  # [n_seq, n_embd] -> [n_seq, n_embd]
    """
        Task: Complete the code of the multi-head attention
        
        Input: 
            x: Tensor
            attn: dictionary that load from gpt2 weight. c_attn and c_proj are the params of two linear layer
            n_head: number of head
        Output: Tensorying multi-head attention and linear transformation, shape [n_seq, n_embd].
    """
    c_attn, c_proj = attn['c_attn'], attn['c_proj']
    # qkv projection 这是 Transformer 中的 一个 trick：只用一个矩阵一次性投影出 Q, K, V，效率高。
    x = linear(x, c_attn)  # [n_seq, n_embd] -> [n_seq, 3*n_embd]
    # Split into qkv
    """
        Task: Split the q,k,v matrix from the tensor x
        Notes: [n_seq, 3*n_embd] -> 3 * [n_seq, n_embd]
    """
    n_embed = x.shape[-1] // 3
    # 这是当前的qkv
    q, k, v = x.split(n_embed, dim=-1)

    # 拼接缓存(第一次)
    if kv_cache[layer_idx]["k"] is not None:
        k = torch.cat([kv_cache[layer_idx]["k"], k], dim=0)  # dim=0 是 seq_len 的方向
        v = torch.cat([kv_cache[layer_idx]["v"], v], dim=0)
    kv_cache[layer_idx]["k"] = k
    kv_cache[layer_idx]["v"] = v

    qkv = (q, k, v)
    # Split into heads 正常的维度是n_embd，而划分为多个头以后用n_embd/n_head这个维度有什么好处？
    qkv_heads = [qkv_part.chunk(n_head, dim=-1) for qkv_part in qkv]  # 3 * [n_seq, n_embd] -> 3 * n_head * [n_seq, n_embd/n_head]
    qkv_heads = list(zip(*qkv_heads))  # [3, n_head, n_seq, n_embd/n_head]

    # Causal mask to hide future inputs from being attended to
    """
        Task: Construct mask matrix
        Notes: 
            | 0  -inf -inf ... -inf |
            | 0    0  -inf ... -inf |
            | 0    0    0  ... -inf |
            |...  ...  ... ...  ... | 
            | 0    0    0  ...   0  |
        Mask is a tensor whose dimension is [n_seq, n_seq]
    """
    q_seq = q.shape[0]
    k_seq = kv_cache[layer_idx]["k"].shape[0]
    # 生成因果掩码
    causal_mask = torch.full((q_seq, k_seq), float('-inf'), device=q.device)
    for i in range(q_seq):
        causal_mask[i, :(i + (k_seq - q_seq) + 1)] = 0  # 允许关注缓存及当前位置之前的token
    # Perform attention over each head
    print(causal_mask)
    out_heads = [attention(q, k, v, causal_mask, layer_idx) for q, k, v in qkv_heads]  # n_head * [n_seq, n_embd/n_head]
    
    # Merge heads
    """
        Task: merge multi-heads results
        Notes: n_head * [n_seq, n_embd/n_head] --> [n_seq, n_embd]
    """
    # 这里又把多头拼了起来，看起来刚拆完又拼上，没什么意义：多头注意力的精髓，不在于结构上拆了，而在于每个“头”在看不同角度的信息、处理不同的语义模式！
    x = torch.cat(out_heads, dim=-1)
    
    # Out projection
    x = linear(x, c_proj)  # [n_seq, n_embd] -> [n_seq, n_embd]
    
    return x


def transformer_block(x, block, layer_idx, n_head):  # [n_seq, n_embd] -> [n_seq, n_embd]
    mlp, attn, ln_1, ln_2 = block['mlp'], block['attn'], block['ln_1'], block['ln_2']
    
    # multi-head causal self attention
    x = x + mha(layer_norm(x, ln_1), attn, layer_idx, n_head=n_head)  # [n_seq, n_embd] -> [n_seq, n_embd]

    # position-wise feed forward network
    x = x + ffn(layer_norm(x, ln_2), mlp)  # [n_seq, n_embd] -> [n_seq, n_embd]

    return x


def gpt2(inputs, params, n_head):  # [n_seq] -> [n_seq, n_vocab]
    wte, wpe, blocks, ln_f = params['wte'], params['wpe'], params['blocks'], params['ln_f']
    if kv_cache[0]["k"] is not None:
        x = wte[inputs[-1:]] + wpe[len(inputs)]  # [n_seq] -> [n_seq, n_embd]
    else:
        # token + positional embeddings
        x = wte[inputs] + wpe[range(len(inputs))]  # [n_seq] -> [n_seq, n_embd]
    
    x = torch.Tensor(x)
    # forward pass through n_layer transformer blocks
    for layer_idx, block in enumerate(blocks):
        x = transformer_block(x, block, layer_idx, n_head=n_head)  # [n_seq, n_embd] -> [n_seq, n_embd]

    # projection to vocab
    x = layer_norm(x, ln_f)  # [n_seq, n_embd] -> [n_seq, n_embd]
    return x @ wte.T  # [n_seq, n_embd] -> [n_seq, n_vocab]


def generate(inputs, params, n_head, n_tokens_to_generate):
    from tqdm import tqdm
    for _ in tqdm(range(n_tokens_to_generate), "generating"):  # auto-regressive decode loop
        logits = gpt2(inputs, params, n_head=n_head)  # model forward pass
        next_id = np.argmax(logits[-1])  # greedy sampling
        inputs.append(int(next_id))  # append prediction to input

    return inputs[len(inputs) - n_tokens_to_generate :]  # only return generated ids


def main(prompt: str, n_tokens_to_generate: int = 5, model_size: str = "124M", models_dir: str = "models"):
    from utils import load_encoder_hparams_and_params
    # load encoder, hparams, and params from the released open-ai gpt-2 files
    encoder, hparams, params = load_encoder_hparams_and_params(model_size, models_dir)

    # encode the input string using the BPE tokenizer
    input_ids = encoder.encode(prompt)

    # make sure we are not surpassing the max sequence length of our model
    assert len(input_ids) + n_tokens_to_generate < hparams["n_ctx"]

    # generate output ids
    start = time.time()
    output_ids = generate(input_ids, params, hparams["n_head"], n_tokens_to_generate)
    end = time.time()
    print(f"Time taken to generate {n_tokens_to_generate} tokens: {end - start:.2f}s")

    # decode the ids back into a string
    output_text = encoder.decode(output_ids)
    with open("output with kvcache.txt", "w", encoding="utf-8") as f:
        f.write(output_text)
    return output_text


if __name__ == "__main__":
    # main(prompt="Alan Turing theorized that computers would one day become")
    import fire
    fire.Fire(main)